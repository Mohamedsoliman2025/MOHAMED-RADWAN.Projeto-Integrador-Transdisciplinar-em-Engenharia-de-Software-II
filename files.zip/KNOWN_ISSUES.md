```markdown
# KNOWN ISSUES

- Upload de arquivos não implementado (carregamento de imagens pode falhar).
- Refresh token não implementado (apenas token de acesso).
- Logs de produção básicos (necessário configurar Winston/Log management).
- Controle refinado de permissões (roles ACL) mínimo.
- Versão do Node sugerida: 18+; caso use outra versão, alguns pacotes podem ter comportamento diferente.
```